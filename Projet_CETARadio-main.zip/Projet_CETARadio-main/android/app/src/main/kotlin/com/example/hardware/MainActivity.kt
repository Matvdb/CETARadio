package com.example.hardware

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
