
import 'package:ceta_radio/myhomepage.dart';

import 'package:flutter/material.dart';


//Démarrage de l'application
void main() {
  runApp(const MyApp());
}

// redirection vers le fichier principal de l'application
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CETA Radio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(
        title: 'CETA Radio',
      ),
    );
  }
}
